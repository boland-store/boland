module.exports = {
  globals: {
    server: true,
    "localStorage": true,
    $: true,
    jQuery: false,
    requirejs: false,
    ga: true,
    Ember: true,
    Promise: true,
    require: true,
    moment: true,
    Set: true,
    Stats: true,
    ClientProxy: true,
    login: true
  },
  root: true,
  parser: '@babel/eslint-parser',
  parserOptions: {
    ecmaVersion: 2017,
    sourceType: 'module',
    ecmaFeatures: {
      experimentalObjectRestSpread: true
    }
  },
  plugins: [
    'ember'
  ],
  env: {
    browser: true
  },
  extends: [
    'eslint:recommended',
    'plugin:ember/recommended'
  ],
  rules: {
    'indent': ['error', 2, {
      "SwitchCase": 1,
      "MemberExpression": 1
    }],
    'no-console': 0,
    'ember/alias-model-in-controller': 0,
    'ember/avoid-leaking-state-in-ember-objects': 0,
    'ember/new-module-imports': 1,
    'ember/no-global-jquery': 0,
    'ember/closure-actions': 1,
    'ember/jquery-ember-run': 1,
    'ember/local-modules': 1,
    'ember/named-functions-in-promises': 0,
    'ember/no-empty-attrs': 1,
    'ember/no-function-prototype-extensions': 1,
    'ember/no-observers': 0,
    'ember/no-on-calls-in-components': 1,
    'ember/no-side-effects': 0,
    'ember/order-in-components': 0,
    'ember/order-in-controllers': 0,
    'ember/order-in-models': 0,
    'ember/order-in-routes': 0,
    'ember/routes-segments-snake-case': 1,
    'ember/no-capital-letters-in-routes': 1,
    'ember/use-brace-expansion': 1,
    'ember/use-ember-get-and-set': 0
  },
  overrides: [
    // node files
    {
      files: [
        '.eslintrc.js',
        '.template-lintrc.js',
        'ember-cli-build.js',
        'testem.js',
        'blueprints/*/index.js',
        'config/**/*.js',
        'lib/*/index.js',
        'server/**/*.js'
      ],
      parserOptions: {
        sourceType: 'script',
        ecmaVersion: 2015
      },
      env: {
        browser: false,
        node: true
      }
    }
  ]
};
