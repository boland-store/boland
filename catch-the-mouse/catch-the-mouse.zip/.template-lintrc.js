'use strict';

module.exports = {
  extends: 'recommended',
  rules: {
    "attribute-indentation": false,
    "block-indentation": false,
    "quotes": false,
    'no-html-comments': false,
    'no-invalid-interactive': false
  }
};
